# Style preference ranker model card

This is an L2-regularized logistic ranker trained from explicit pairwise preference labels. It ranks existing text; it does not generate or rewrite prose.

- Dataset: synthetic-preference-v1-20261031
- Synthetic training: True
- Holdout scope: within-author document groups
- Held-out pairs: 24; independent groups: 6
- Held-out accuracy: 1.0; group bootstrap95: [1, 1]
- Held-out Brier score: 0.03331481596188249; log loss: 0.15169008979711412
- Training-majority baseline test accuracy: 0.4583333333333333
- Early stopping iteration: 78
- No test labels are used for gradient updates, scaling, or early stopping.
- Scientific validity and real-author efficacy are NOT ESTABLISHED.

## Intended use and limitations

Use only as an interpretable preference signal for the labeled population. Synthetic mechanism checks demonstrate fitting behavior, not a particular author's preferences. English-oriented token and passive-pattern heuristics can misread text. Length-dependent features and corpus shift can alter scores. Inspect per-group uncertainty and calibration before considering any practical use.

The model uses no topic embeddings and has zero pairwise intercept, so swapping left and right complements the preference probability. Human labels are required for a real corpus; missing labels are never inferred. Document families, source hashes, and normalized texts are kept in one split; author holdout is optional and is reported explicitly.

## Learned coefficients

| Feature | Coefficient | Train-only scale |
| --- | ---: | ---: |
| log_words | -0.00501653 | 0.802904 |
| mean_sentence_words | -0.507851 | 9.54908 |
| sentence_length_sd | 0.0334131 | 5.46471 |
| mean_word_length | -0.0304527 | 0.417704 |
| mean_paragraph_words | -0.0389157 | 22.5819 |
| hedges_per_1000 | 1.16119 | 83.0797 |
| first_person_per_1000 | 0.920787 | 49.0537 |
| transitions_per_1000 | 0.21836 | 39.026 |
| passive_pattern_rate | -0.786752 | 1.28523 |
| semicolons_per_1000 | 0.0358224 | 33.3099 |
| parentheses_per_1000 | 0.28155 | 26.029 |
| type_token_ratio | 0.0959923 | 0.269555 |
