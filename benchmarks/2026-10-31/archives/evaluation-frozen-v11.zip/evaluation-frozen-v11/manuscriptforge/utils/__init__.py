"""Utility helpers for ManuscriptForge."""
