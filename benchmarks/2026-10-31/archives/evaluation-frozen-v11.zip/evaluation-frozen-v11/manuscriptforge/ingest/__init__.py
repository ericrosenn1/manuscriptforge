"""Input ingestion modules."""
