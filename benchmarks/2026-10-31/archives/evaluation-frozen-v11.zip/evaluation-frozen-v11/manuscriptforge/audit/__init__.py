"""Manuscript audit modules."""
