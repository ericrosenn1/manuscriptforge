"""Manuscript drafting modules."""
