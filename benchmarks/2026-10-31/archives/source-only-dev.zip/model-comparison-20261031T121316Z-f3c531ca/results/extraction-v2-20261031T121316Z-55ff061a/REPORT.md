# Source-only extraction evaluation v2

Models received raw sources, the query, and generic count/duration label hints. No reference fact values, answer IDs, or expected labels were supplied.

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| cases | 48 | 48 |
| complete_case_rate | 1.0 | 1.0 |
| responsive_precision_micro | 1.0 | 1.0 |
| responsive_recall_micro | 1.0 | 1.0 |
| required_abstention_accuracy | 1.0 | 1.0 |
| execution_failures | 0 | 0 |
| wrong_values | 0 | 0 |
| wrong_units | 0 | 0 |
| wrong_sources | 0 | 0 |

Paired complete-case delta: 0.
Evaluator source changes during execution: [].

Returned proposal tuples are aligned with hidden reference tuples only after execution. Quote offsets and source hashes are independently rechecked against a copy of the original source text. Predicate semantics and scientific validity remain unverified. Ranking metrics are not applicable to this extraction-only task.

JSONL rows are flushed incrementally. progress.json records completed calls so interrupted work remains inspectable. Resource totals distinguish measured usage from missing records; failure costs may require the external shared ledger.
