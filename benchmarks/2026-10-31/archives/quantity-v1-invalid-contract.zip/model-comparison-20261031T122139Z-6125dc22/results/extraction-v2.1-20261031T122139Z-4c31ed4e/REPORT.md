# Source-only extraction evaluation 2.1-quantities

Models received raw sources, the query, and generic count/duration label hints. No reference fact values, answer IDs, or expected labels were supplied.

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| cases | 84 | 84 |
| complete_case_rate | 0.8452380952380952 | 0.27380952380952384 |
| responsive_precision_micro | 0.8194444444444444 | 0.2916666666666667 |
| responsive_recall_micro | 0.8194444444444444 | 0.19444444444444445 |
| required_abstention_accuracy | 1.0 | 0.75 |
| execution_failures | 0 | 27 |
| wrong_values | 5 | 25 |
| wrong_units | 0 | 0 |
| wrong_sources | 0 | 0 |

Paired complete-case delta: -0.5714285714285714.
Evaluator source changes during execution: [].

Returned proposal tuples are aligned with hidden reference tuples only after execution. Quote offsets and source hashes are independently rechecked against a copy of the original source text. Predicate semantics and scientific validity remain unverified. Ranking metrics are not applicable to this extraction-only task.

JSONL rows are flushed incrementally. progress.json records completed calls so interrupted work remains inspectable. Resource totals distinguish measured usage from missing records; failure costs may require the external shared ledger.
